interface TextAnalyzer{
	Label processText(String text);
}